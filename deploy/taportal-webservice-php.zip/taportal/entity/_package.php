<?php

require_once 'taportal/entity/DataFormatSpecificationConstants.php';
require_once 'taportal/entity/EntityBase.php';
require_once 'taportal/entity/PublicationTypeEnum.php';

require_once 'taportal/entity/Institute.php';
require_once 'taportal/entity/Expert.php';
require_once 'taportal/entity/Project.php';
require_once 'taportal/entity/Publication.php';

require_once 'taportal/entity/TheInstitutes.php';
require_once 'taportal/entity/TheExperts.php';
require_once 'taportal/entity/TheProjects.php';
require_once 'taportal/entity/ThePublications.php';

?>