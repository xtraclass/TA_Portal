<?php

final class ObjectBuilder
{



  public function __construct( $logger )
  {
    $this->logger = $logger;
  }



  public function build( $jsonObject )
  {
    if ( is_null( $jsonObject ) )
    {
      throw new InvalidArgumentException( 'Argument "$$jsonObject" must not be NULL.' );
    }
    
    $institutesByUK = array();
    $expertsByUK = array();
    
    try
    {
      $institutes = $this->parseTheInstitutes( $jsonObject, &$institutesByUK );
    }
    catch ( Exception $x )
    {
      throw new RuntimeException( "ERROR parsing data of institutes", 1234, $x );
    }
    try
    {
      $experts = $this->parseTheExperts( $jsonObject, &$institutesByUK, &$expertsByUK );
    }
    catch ( Exception $x )
    {
      throw new RuntimeException( "ERROR parsing data of experts", 1234, $x );
    }
    try
    {
      $projects = $this->parseTheProjects( $jsonObject, &$expertsByUK );
    }
    catch ( Exception $x )
    {
      throw new RuntimeException( "ERROR parsing data of projects", 1234, $x );
    }
    try
    {
      $publications = $this->parseThePublications( $jsonObject, &$institutesByUK );
    }
    catch ( Exception $x )
    {
      throw new RuntimeException( "ERROR parsing data of publications", 1234, $x );
    }
    
    return array( $institutes, $experts, $projects, $publications );
  }



  private function parseTheInstitutes( $object, &$institutesByUK )
  {
    if ( is_null( $object->I ) )
    {
      $this->log( 'No institutes found.' );
      return new TheInstitutes();
    }
    
    $theInstitutes = new TheInstitutes();
    
    if ( count( $object->I ) >= 1 )
    {
      foreach ( $object->I as $jsonObject )
      {
        try
        {
          $theInstitutes->addInstitute( $this->parseOneInstitute( $jsonObject, $object, &$institutesByUK ) );
        }
        catch ( Exception $x )
        {
          $this->log( "Could not parse data of one institute for $jsonObject", $x );
        }
      }
    }
    else
    {
      $this->log( 'No institutes found, only empty "I" element.' );
    }
    
    return $theInstitutes;
  }



  private function parseTheExperts( $object, &$institutesByUK, &$expertsByUK )
  {
    if ( is_null( $object->E ) )
    {
      $this->log( 'No experts found.' );
      return new TheExperts();
    }
    
    $theExperts = new TheExperts();
    
    if ( count( $object->E ) >= 1 )
    {
      foreach ( $object->E as $jsonObject )
      {
        try
        {
          $theExperts->addExpert( $this->parseOneExpert( $jsonObject, $object, &$institutesByUK, &$expertsByUK ) );
        }
        catch ( Exception $x )
        {
          $this->log( "Could not parse data of one expert for $jsonObject", $x );
        }
      }
    }
    else
    {
      $this->log( 'No experts found, only empty "E" element.' );
    }
    
    return $theExperts;
  }



  private function parseTheProjects( $object, &$expertsByUK )
  {
    
    if ( is_null( $object->R ) )
    {
      $this->log( 'No projects found.' );
      return new TheProjects();
    }
    
    $theProjects = new TheProjects();
    
    if ( count( $object->R ) >= 1 )
    {
      foreach ( $object->R as $jsonObject )
      {
        try
        {
          $theProjects->addProject( $this->parseOneProject( $jsonObject, $object, &$expertsByUK ) );
        }
        catch ( Exception $x )
        {
          $this->log( "Could not parse data of one project for $jsonObject", $x );
        }
      }
    }
    else
    {
      $this->log( 'No projects found, only empty "R" element.' );
    }
    
    return $theProjects;
  }



  private function parseThePublications( $object, &$institutesByUK )
  {
    if ( is_null( $object->U ) )
    {
      $this->log( 'No publications found.' );
      return new ThePublications();
    }
    
    $thePublications = new ThePublications();
    
    if ( count( $object->U ) >= 1 )
    {
      foreach ( $object->U as $jsonObject )
      {
        try
        {
          $thePublications->addPublication( $this->parseOnePublication( $jsonObject, $object, &$institutesByUK ) );
        }
        catch ( Exception $x )
        {
          $this->log( "Could not parse data of one publication for $jsonObject", $x );
        }
      }
    }
    else
    {
      $this->log( 'No publications found, only empty "U" element.' );
    }
    
    return $thePublications;
  }



  private function parseOneInstitute( $jsonObject, $object, &$institutesByUK )
  {
    if ( is_null( $jsonObject ) )
    {
      return NULL;
    }
    
    $institute = new Institute();
    
    $this->set( $institute, 'Abbreviation', $jsonObject, 'E' );
    $this->set( $institute, 'Name', $jsonObject, 'N' );
    $this->set( $institute, 'CountryCode', $jsonObject, 'O' );
    $this->set( $institute, 'ZipCode', $jsonObject, 'Z' );
    $this->set( $institute, 'City', $jsonObject, 'C' );
    $this->set( $institute, 'Street', $jsonObject, 'S' );
    $this->set( $institute, 'Description', $jsonObject, 'D' );
    $this->set( $institute, 'URL', $jsonObject, 'U' );
    
    if ( $this->lookForAdditionalProperties( $jsonObject, 'E, N, O, Z, C, S, D, U, ', 'institute', $institute ) )
    {
      try
      {
        $institutesByUK[ JSONBuilder::buildUKofInsitutue( $institute ) ] = $institute;
        
        $this->validateObject( $institute );
      }
      catch ( Exception $x )
      {
        $this->log( "No additional properties for $jsonObject", $x );
      }
    }
    
    return $institute;
  }



  private function parseOneExpert( $jsonObject, $object, &$institutesByUK, &$expertsByUK )
  {
    if ( is_null( $jsonObject ) )
    {
      return NULL;
    }
    
    $expert = new Expert();
    
    $this->set( $expert, 'Surname', $jsonObject, 'S' );
    $this->set( $expert, 'Firstnames', $jsonObject, 'F' );
    $this->set( $expert, 'ExpTitle', $jsonObject, 'T' );
    $this->set( $expert, 'EMail', $jsonObject, 'E' );
    $this->set( $expert, 'PhoneNumber', $jsonObject, 'P' );
    $this->set( $expert, 'SkypeID', $jsonObject, 'D' );
    $this->set( $expert, 'Expertise', $jsonObject, 'X' );
    $this->set( $expert, 'EmplURL', $jsonObject, 'L' );
    $this->set( $expert, 'TAPublicationURL', $jsonObject, 'U' );
    $this->set( $expert, 'TAProjectURL', $jsonObject, 'J' );
    
    if ( $this->lookForAdditionalProperties( $jsonObject, 'S, F, T, E, P, D, X, L, U, J, I, ', 'expert', $expert ) )
    {
      try
      {
        $expertsByUK[ JSONBuilder::buildUKofExpert( $expert ) ] = $expert;
        
        if ( !is_null( $jsonObject->I ) and !is_null( $jsonObject->I->E ) )
        {
          
          $uk = '{"E":"' . $jsonObject->I->E . '"}';
          
          if ( isset( $institutesByUK[ $uk ] ) )
          {
            
            $institute = $institutesByUK[ $uk ];
            
            if ( !is_null( $institute ) )
            {
              $expert->setInstitute( $institute );
            }
            else
            {
              $this->log( "JSON-ERROR: There was no institute found for the unique key {$uk} for the expert [{$expert->getSurname()} {$expert->getFirstnames()}]" );
            }
          }
        }
        else
        {
          $this->log( "JSON ERROR: Expert [{$expert->getSurname()} {$expert->getFirstnames()}] must have an institute where the expert belongs to." );
        }
        
        $this->validateObject( $expert );
      }
      catch ( Exception $x )
      {
        $this->log( "No additional properties for $jsonObject", $x );
      }
    }
    
    return $expert;
  }



  private function parseOneProject( $jsonObject, $object, &$expertsByUK )
  {
    if ( is_null( $jsonObject ) )
    {
      return NULL;
    }
    
    $project = new Project();
    
    $this->set( $project, 'ShortTitleE', $jsonObject, 'S' );
    $this->set( $project, 'LongTitleE', $jsonObject, 'L' );
    $this->set( $project, 'ShortDescriptionE', $jsonObject, 'D' );
    $this->set( $project, 'StartDate', $jsonObject, 'T' );
    $this->set( $project, 'EndDate', $jsonObject, 'N' );
    $this->set( $project, 'PartnerCountries', $jsonObject, 'Y' );
    $this->set( $project, 'ScopeCountries', $jsonObject, 'Z' );
    $this->set( $project, 'HomePage', $jsonObject, 'H' );
    $this->set( $project, 'Focus', $jsonObject, 'U' );
    
    if ( $this->lookForAdditionalProperties( $jsonObject, 'S, L, D, T, N, Y, Z, H, U, O, ', 'project', $project ) )
    {
      try
      {
        if ( !is_null( $jsonObject->O ) and !is_null( $jsonObject->O->S ) and !is_null( $jsonObject->O->F ) )
        {
          $uk = '{"S":"' . $jsonObject->O->S . '","F":"' . $jsonObject->O->F . '"}';
          $expert = $expertsByUK[ $uk ];
          if ( !is_null( $expert ) )
          {
            $project->setContactPerson( $expert );
          }
          else
          {
            $this->log( "JSON-ERROR: There was no expert found for the unique key {$uk} for the project [{$project->getShortTitleE()}]" );
          }
        }
        else
        {
          $this->log( "JSON ERROR: Project [{$project->getShortTitleE()}] must have a contact person (expert) where the project belongs to." );
        }
        
        $this->validateObject( $project );
      }
      catch ( Exception $x )
      {
        $this->log( "No additional properties for $jsonObject", $x );
      }
    }
    
    return $project;
  }



  private function parseOnePublication( $jsonObject, $object, &$institutesByUK )
  {
    if ( is_null( $jsonObject ) )
    {
      return NULL;
    }
    
    $publication = new Publication();
    
    $this->set( $publication, 'Quotation', $jsonObject, 'Q' );
    $this->set( $publication, 'PublDate', $jsonObject, 'D' );
    $this->set( $publication, 'ShortDescription', $jsonObject, 'S' );
    
    if ( !is_null( $jsonObject->T ) )
    {
      $enum = PublicationTypeEnum::byStringValue( $jsonObject->T );
      if ( !is_null( $enum ) )
      {
        $publication->setPublType( $enum );
      }
    }
    
    if ( $this->lookForAdditionalProperties( $jsonObject, 'Q, D, S, T, I, ', 'publication', $publication ) )
    {
      try
      {
        if ( !is_null( $jsonObject->I ) and !is_null( $jsonObject->I->E ) )
        {
          $uk = '{"E":"' . $jsonObject->I->E . '"}';
          $institute = $institutesByUK[ $uk ];
          if ( !is_null( $institute ) )
          {
            $publication->setInstitute( $institute );
          }
          else
          {
            $this->log( "JSON-ERROR: There is no institute found for the unique key {$uk} for the publication [{$publication->getQuotation()} {$publication->getPublDate()}]" );
          }
        }
        else
        {
          $this->log( "JSON ERROR: Publication [{$publication->getQuotation()} {$publication->getPublDate()}] must have an institute where the publication belongs to." );
        }
        
        $this->validateObject( $publication );
      }
      catch ( Exception $x )
      {
        $this->log( "No additional properties for $jsonObject", $x );
      }
    }
    
    return $publication;
  }



  private function set( $object, $propertyName, $jsonObject, $jsonPropertyName )
  {
    if ( isset( $jsonObject->{$jsonPropertyName} ) )
    {
      try
      {
        $object->{"set" . $propertyName}( $this->replacePipesByLineBreaks( $jsonObject->{$jsonPropertyName} ) );
      }
      catch ( Exception $x )
      {
        $this->log( NULL, $x );
      }
    }
    else
    {
      if ( $object->isRequiredProperty( $propertyName ) )
      {
        $this->log( "Did not find property {$jsonPropertyName} in JSON text of [{$object}]." );
      }
    }
  }



  private function lookForAdditionalProperties( $jsonObject, $propertyNames, $entityName, $object )
  {
    $additionalProperties = '';
    $reflector = new ReflectionObject( $jsonObject );
    
    foreach ( $reflector->getProperties( ReflectionProperty::IS_PUBLIC ) as $property )
    {
      if ( strpos( $propertyNames, $property->getName() . ', ' ) <= -1 )
      {
        $additionalProperties .= $property->getName() . ', ';
      }
    }
    
    if ( strlen( $additionalProperties ) >= 3 )
    {
      $additionalProperties = substr( $additionalProperties, 0, strlen( $additionalProperties ) - 2 );
      $this->log( 'The ' . $entityName . ' [' . $object . /***/
      '] has the following additional, invalid properties: ' . $additionalProperties );
      return FALSE;
    }
    
    return TRUE;
  }



  private function validateObject( $object )
  {
    if ( !$this->logger->wasErrorLogged() )
    {
      try
      {
        $object->validate();
      }
      catch ( InvalidArgumentException $x )
      {
        $this->log( NULL, $x );
      }
    }
  }



  private function replacePipesByLineBreaks( $text )
  {
    return str_replace( '||||', "\n", $text );
  }



  private function log( $message, $exception = NULL, $institute = NULL, $harvestId = NULL )
  {
    $this->logger->log( $message, $exception, $institute, $harvestId );
  }

  private $logger;

}

?>