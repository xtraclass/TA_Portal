<?php

require_once 'PHPUnit\Framework\TestCase.php';

require_once 'taportal/harvester/_Classes.php';
require_once 'taportal/tests/_package.php';


?>