<?php

require_once 'taportal/tests/FakedEntitiesMaker.php';
require_once 'taportal/tests/TestBase.php';
require_once 'taportal/tests/VectorTest.php';
require_once 'taportal/tests/ExpertTest.php';
require_once 'taportal/tests/InstituteTest.php';
require_once 'taportal/tests/ProjectTest.php';
require_once 'taportal/tests/PublicationTest.php';
require_once 'taportal/tests/JSONBuilderTest.php';

?>