<?php

require_once 'taportal/util/Vector.php';

?>